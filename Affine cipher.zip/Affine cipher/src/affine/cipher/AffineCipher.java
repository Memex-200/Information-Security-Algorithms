/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package affine.cipher;

/**
 *
 * @author Eman Hassan
 */
import java.util.Scanner;

public class AffineCipher {
   static int a;
   static int b;

   public static String encryptMessage(char[] msg) {
       // Cipher Text initially empty
       String cipher = "";
       for (int i = 0; i < msg.length; i++) {
           if (msg[i] != ' ') {
               cipher = cipher + (char) ((((a * (msg[i] - 'A')) + b) % 26) + 'A');
           } else {
               cipher += msg[i];
           }
       }
       return cipher;
   }

   public static String decryptCipher(String cipher) {
       String msg = "";
       int a_inv = 0;
       int flag = 0;

       for (int i = 0; i < 26; i++) {
           flag = (a * i) % 26;
           if (flag == 1) {
               a_inv = i;
           }
       }
       for (int i = 0; i < cipher.length(); i++) {
           if (cipher.charAt(i) != ' ') {
               msg = msg + (char) (((a_inv * ((cipher.charAt(i) + 'A' - b)) % 26)) + 'A');
           } else {
               msg += cipher.charAt(i);
           }
       }
       return msg;
   }

   public static void main(String[] args) {
       Scanner scanner = new Scanner(System.in);

       System.out.print("Enter the value of 'a' for Affine Cipher: ");
       a = scanner.nextInt();

       System.out.print("Enter the value of 'b' for Affine Cipher: ");
       b = scanner.nextInt();

       scanner.nextLine(); // Consume the newline character

       System.out.print("Enter the message to be encrypted with Affine Cipher: ");
       String msg = scanner.nextLine().toUpperCase();

       // Calling encryption function
       String cipherText = encryptMessage(msg.toCharArray());
       System.out.println("Encrypted Message is : " + cipherText);

       // Calling Decryption function
       System.out.println("Decrypted Message is: " + decryptCipher(cipherText));
   }
}

