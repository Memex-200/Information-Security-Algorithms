/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sdes;
import java.util.Scanner;
/**
 *
 * @author Eman Hassan
 */
public class SDES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner scanner = new Scanner(System.in);

        System.out.println("Enter plaintext (8 bits):");
        String plaintext = scanner.next();
        System.out.println("Enter key (10 bits):");
        String key = scanner.next();

        String ciphertext = des_encrypt(plaintext, key);
        System.out.println("Encrypted ciphertext: " + ciphertext);

        scanner.close();
    }

    // encryption
    public static String des_encrypt(String plaintext, String key) {
        String state = plaintext;

        // subkey generation (scheduling) = generate 2 subkeys
        String[] subkeys = generate_subkey(key);

        // initial permutation
        state = ip(state);

        // 2 feistel networks
        for (int i = 0; i < 2; i++) {
            state = feistel(state, subkeys[i]);
        }

        // final permutation
        state = ip_1(state);

        String ciphertext = state;

        return ciphertext;
    }

    public static String[] generate_subkey(String key) {
        // P10
        key = p10(key);

        // split key
        String key_l = key.substring(0, 5);
        String key_r = key.substring(5);

        // LS-1
        String key_l_shifted = leftShift(key_l, 1);
        String key_r_shifted = leftShift(key_r, 1);

        key = key_l_shifted + key_r_shifted;

        // P8 --> subkey 0
        String subkey_0 = p8(key);

        // LS-2
        key_l_shifted = leftShift(key_l_shifted, 2);
        key_r_shifted = leftShift(key_r_shifted, 2);

        key = key_l_shifted + key_r_shifted;

        // P8 --> subkey 1
        String subkey_1 = p8(key);

        return new String[]{subkey_0, subkey_1};
    }

    public static String feistel(String state, String subkey) {
        // split state
        String state_l = state.substring(0, 4);
        String state_r = state.substring(4);

        // first round function
        String f_state_r = round_function(state_r, subkey);

        // XOR right side with left side of the state
        state_l = xor(state_l, f_state_r);

        state = state_r + state_l;

        return state;
    }

    public static String round_function(String state, String subkey) {
        // E/P (Expansion Permutation)
        state = e_p(state);

        // XOR with subkey
        state = xor(state, subkey);

        // Sbox
        state = sbox(state);

        // P4
        state = p4(state);

        return state;
    }

    // === permutation & substitution functions === //
    public static String p10(String input) {
        int[] P10 = {2, 4, 1, 6, 3, 9, 0, 8, 7, 5};
        return permute(input, P10);
    }

    public static String p8(String input) {
        int[] P8 = {5, 2, 6, 3, 7, 4, 9, 8};
        return permute(input, P8);
    }

    public static String p4(String input) {
        int[] P4 = {1, 3, 2, 0};
        return permute(input, P4);
    }

    // IP (Initial Permuation)
    public static String ip(String input) {
        int[] IP = {1, 5, 2, 0, 3, 7, 4, 6};
        return permute(input, IP);
    }

    // IP**-1 (Final Permutation)
    public static String ip_1(String input) {
        int[] IP_1 = {3, 0, 2, 4, 6, 1, 7, 5};
        return permute(input, IP_1);
    }

    // E/P (Expansion Permutation)
    public static String e_p(String input) {
        int[] E_P = {3, 0, 1, 2, 1, 2, 3, 0};
        return permute(input, E_P);
    }

    public static String sbox(String input) {
        String[][] S0 = {{"01", "11", "00", "11"}, {"00", "10", "10", "01"}, {"11", "01", "01", "11"}, {"10", "00", "11", "10"}};
        String[][] S1 = {{"00", "10", "11", "10"}, {"01", "00", "00", "01"}, {"10", "01", "01", "00"}, {"11", "11", "00", "11"}};

        String input_0 = input.substring(0, 4);
        String input_1 = input.substring(4);

        int row0 = Integer.parseInt(input_0.substring(0, 1) + input_0.substring(3, 4), 2);
        int col0 = Integer.parseInt(input_0.substring(1, 3), 2);

        int row1 = Integer.parseInt(input_1.substring(0, 1) + input_1.substring(3, 4), 2);
        int col1 = Integer.parseInt(input_1.substring(1, 3), 2);

        return S0[row0][col0] + S1[row1][col1];
    }

    public static String permute(String input, int[] permutation) {
        StringBuilder output = new StringBuilder();
        for (int i : permutation) {
            output.append(input.charAt(i));
        }
        return output.toString();
    }

    public static String xor(String a, String b) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < a.length(); i++) {
            result.append(a.charAt(i) ^ b.charAt(i));
        }
        return result.toString();
    }

    public static String leftShift(String input, int shift) {
        return input.substring(shift) + input.substring(0, shift);
    }
    }
    

