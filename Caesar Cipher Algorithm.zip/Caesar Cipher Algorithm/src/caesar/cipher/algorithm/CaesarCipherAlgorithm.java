/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caesar.cipher.algorithm;
import java.util.*;
/**
 *
 * @author Eman Hassan Mahmoud
 */
public class CaesarCipherAlgorithm {

    /**
     * @param args the command line arguments
    */
public static StringBuffer enc(String message , int key)
{
    StringBuffer res = new StringBuffer(); 
    for(int i=0;i<message.length();i++)
    {
        if(Character.isUpperCase(message.charAt(i)))
        {
            char ch = (char)(((int)message.charAt(i)+ key - 65)%26+65);
            res.append(ch);
        }
        else 
        {
            char ch = (char)(((int)message.charAt(i) + key -97 )%26+97);
            res.append(ch);
        }
    }
    return res;
}
public static StringBuffer dec(String message , int key)
{
    StringBuffer res = new StringBuffer(); 
    for(int i=0;i<message.length();i++)
    {
        if(Character.isUpperCase(message.charAt(i)))
        {
            char ch = (char)(((int)message.charAt(i) - key - 65)%26+65);
            res.append(ch);
        }
        else 
        {
            char ch = (char)(((int)message.charAt(i) - key -97 )%26+97);
            res.append(ch);
        }
    }
    return res;
}
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner e = new Scanner (System.in);
        System.out.println("Enter message :");
        String message = e.nextLine();
        System.out.println("Enter key :");
        int key = e.nextInt();
        System.out.println("Encrypt or Decrypt ?");
        String choice = e.next();
        if (choice.equals("Encrypt"))
        {
            System.out.println(enc(message,key));
        }
        else 
        {
            System.out.println(dec(message,key));
        }
        
    }
    
}
